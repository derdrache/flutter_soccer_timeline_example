Flaticon license
Free for personal and commercial use with attribution

Icons attribution:
- Soccer: <a href="https://www.flaticon.com/free-icons/soccer" title="soccer icons">Soccer icons created by Freepik - Flaticon</a>
- Whistle: <a href="https://www.flaticon.com/free-icons/music-and-multimedia" title="music and multimedia icons">Music and multimedia icons created by Freepik - Flaticon</a>
- Yellow card: <a href="https://www.flaticon.com/free-icons/yellow-card" title="yellow card icons">Yellow card icons created by RIkas Dzihab - Flaticon</a>
- Red card: <a href="https://www.flaticon.com/free-icons/red-card" title="red card icons">Red card icons created by RIkas Dzihab - Flaticon</a>
- First aid kit: <a href="https://www.flaticon.com/free-icons/first-aid-kit" title="first aid kit icons">First aid kit icons created by Freepik - Flaticon</a>
- Offside flag: <a href="https://www.flaticon.com/free-icons/referee" title="referee icons">Referee icons created by Freepik - Flaticon</a>
